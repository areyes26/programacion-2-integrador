let controlador = {
	/* Aca se escribe lo que se ejecuta*/
};

module.exports = controlador;
