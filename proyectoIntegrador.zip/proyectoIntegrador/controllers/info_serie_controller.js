let controlador = {};

module.exports = controlador;
